document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Footer year ---------- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Mobile nav toggle ---------- */
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      var isOpen = navLinks.classList.toggle('is-open');
      navToggle.classList.toggle('is-open', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navLinks.classList.remove('is-open');
        navToggle.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------- Skills tab filter ---------- */
  var tabs = document.querySelectorAll('.skill-tab');
  var panels = document.querySelectorAll('.skill-panel');

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var targetId = tab.getAttribute('data-target');

      tabs.forEach(function (t) {
        t.classList.remove('is-active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('is-active');
      tab.setAttribute('aria-selected', 'true');

      panels.forEach(function (panel) {
        var isTarget = panel.id === targetId;
        panel.classList.toggle('is-active', isTarget);
        panel.hidden = !isTarget;
      });
    });
  });

  /* ---------- Hero eyebrow typing effect ---------- */
  var typingEl = document.querySelector('[data-typing]');
  if (typingEl && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var fullText = typingEl.textContent;
    typingEl.textContent = '';
    var i = 0;
    (function typeChar() {
      if (i <= fullText.length) {
        typingEl.textContent = fullText.slice(0, i);
        i++;
        setTimeout(typeChar, 18);
      }
    })();
  }

  /* ---------- Animated KPI counters (hero) ---------- */
  var counters = document.querySelectorAll('[data-count]');
  var countersAnimated = false;

  function animateCounters() {
    if (countersAnimated) return;
    countersAnimated = true;
    counters.forEach(function (el) {
      var target = parseInt(el.getAttribute('data-count'), 10) || 0;
      var current = 0;
      var step = Math.max(1, Math.ceil(target / 30));
      var timer = setInterval(function () {
        current += step;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        el.textContent = current;
      }, 40);
    });
  }

  /* ---------- Scroll reveal for sections ---------- */
  var revealTargets = document.querySelectorAll(
    '.service-card, .project-card, .dash-card, .process-step, .stat, .skill-panel li'
  );

  if ('IntersectionObserver' in window) {
    var revealObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

    revealTargets.forEach(function (el, idx) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = 'opacity 500ms ease ' + Math.min(idx % 6, 5) * 60 + 'ms, transform 500ms ease ' + Math.min(idx % 6, 5) * 60 + 'ms';
      revealObserver.observe(el);
    });

    var heroVisual = document.querySelector('.hero-visual');
    if (heroVisual) {
      var kpiObserver = new IntersectionObserver(function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounters();
            obs.disconnect();
          }
        });
      }, { threshold: 0.3 });
      kpiObserver.observe(heroVisual);
    } else {
      animateCounters();
    }
  } else {
    revealTargets.forEach(function (el) {
      el.style.opacity = '1';
    });
    animateCounters();
  }

  /* ---------- Active nav link on scroll ---------- */
  var sections = document.querySelectorAll('main section[id]');
  var navAnchors = document.querySelectorAll('.nav-links a');

  function setActiveLink() {
    var scrollPos = window.scrollY + 120;
    var currentId = null;

    sections.forEach(function (section) {
      if (section.offsetTop <= scrollPos) {
        currentId = section.id;
      }
    });

    navAnchors.forEach(function (a) {
      var isActive = a.getAttribute('href') === '#' + currentId;
      a.style.color = isActive ? 'var(--text)' : '';
    });
  }
  window.addEventListener('scroll', setActiveLink, { passive: true });
  setActiveLink();

  /* ---------- Contact Me: copy details to clipboard ---------- */
  var contactMeBtn = document.getElementById('contactMeBtn');
  var copyToast = document.getElementById('copyToast');
  var EMAIL = 'adnanalikorai515@gmail.com';
  var PHONE = '+92 321 5933670';

  if (contactMeBtn && copyToast) {
    contactMeBtn.addEventListener('click', function () {
      var details = 'Adnan Ali Korai\nEmail: ' + EMAIL + '\nPhone: ' + PHONE;

      function showToast(message) {
        copyToast.textContent = message;
        copyToast.classList.add('is-visible');
        setTimeout(function () {
          copyToast.classList.remove('is-visible');
        }, 3200);
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(details).then(function () {
          showToast('Contact details copied to clipboard.');
        }).catch(function () {
          showToast('Email: ' + EMAIL + '  ·  Phone: ' + PHONE);
        });
      } else {
        showToast('Email: ' + EMAIL + '  ·  Phone: ' + PHONE);
      }
    });
  }

  /* ---------- Social placeholder notice ---------- */
  document.querySelectorAll('.social-link[data-placeholder]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      if (link.getAttribute('href') === '#') {
        e.preventDefault();
      }
    });
  });

});
